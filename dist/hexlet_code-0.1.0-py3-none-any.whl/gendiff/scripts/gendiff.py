import argparse
import pathlib
from gendiff.generate_difference import generate_diff


def main():
    parser = argparse.ArgumentParser(description='Generate diff',
                                     conflict_handler='resolve')
    parser.add_argument('first_file', type=pathlib.Path)
    parser.add_argument('second_file', type=pathlib.Path)
    parser.add_argument('-f', '--format', dest='format',
                        metavar='FORMAT', default='stylish',
                        help='set format of output (default: stylish)')
    args = parser.parse_args()

    if not args.format:
        args.format = 'stylish'
    print(generate_diff(args.first_file, args.second_file, args.format))


if __name__ == '__main__':
    main()
